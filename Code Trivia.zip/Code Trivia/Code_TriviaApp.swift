//
//  Code_TriviaApp.swift
//  Code Trivia
//
//  Created by T'Cheznavia  Cherry on 2/3/24.
//

import SwiftUI

@main
struct Code_TriviaApp: App {
    var body: some Scene {
        WindowGroup {
            WelcomeView()
        }
    }
}
